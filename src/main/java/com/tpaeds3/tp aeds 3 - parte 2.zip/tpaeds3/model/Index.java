package com.tpaeds3.tpaeds3.model;

public class Index {
  private String lastName;
  private String newName;
  private Long newPosition;
  
  public String getLastName() {
    return lastName;
  }
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }
  public String getNewName() {
    return newName;
  }
  public void setNewName(String newName) {
    this.newName = newName;
  }
  public Long getNewPosition() {
    return newPosition;
  }
  public void setNewPosition(Long newPosition) {
    this.newPosition = newPosition;
  }
}
